package com.zybooks.weighttrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


// SetGoalActivity allows users to view their current goal weight
// and set a new one. The new goal weight is saved to the database.

public class SetGoalActivity extends AppCompatActivity {

    private TextView currentGoalWeightTextView;
    private EditText newGoalInput;
    private Button setNewGoalButton, cancelButton;
    private DatabaseHelper dbHelper;
    private int userId; // Current user's ID

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_goal);

        // Initialize DatabaseHelper
        dbHelper = new DatabaseHelper(this);

        // Retrieve the user ID passed from DashboardActivity
        userId = getIntent().getIntExtra("user_id", -1);

        // Initialize UI components
        currentGoalWeightTextView = findViewById(R.id.original_goal_weight);
        newGoalInput = findViewById(R.id.new_goal_input);
        setNewGoalButton = findViewById(R.id.set_new_goal_button);
        cancelButton = findViewById(R.id.goal_cancel_button);

        // Display the current goal weight
        displayCurrentGoalWeight();

        // Set button click listeners
        setNewGoalButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setNewGoalWeight();
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // close and return to dashboard
                finish();
            }
        });
    }


    //Retrieves and displays the user's current goal weight.

    private void displayCurrentGoalWeight() {
        double goalWeight = dbHelper.getGoalWeightForUser(userId);

        if (goalWeight == 0.0) {
            currentGoalWeightTextView.setText("Current Goal Weight: Not set");
        } else {
            currentGoalWeightTextView.setText("Current Goal Weight: " + goalWeight + " lbs");
        }
    }


    //Sets a new goal weight and updates it in the database.

    private void setNewGoalWeight() {
        // Get user input for new goal weight
        String newGoalStr = newGoalInput.getText().toString().trim();

        // Check if input is empty
        if (TextUtils.isEmpty(newGoalStr)) {
            Toast.makeText(this, "Please enter a goal weight", Toast.LENGTH_SHORT).show();
            return;
        }

        // Convert input to a number
        try {
            double newGoalWeight = Double.parseDouble(newGoalStr);

            // Update the goal weight in the database
            dbHelper.setGoalWeightForUser(userId, newGoalWeight);

            // Show confirmation and return to Dashboard
            Toast.makeText(this, "Goal weight updated successfully!", Toast.LENGTH_SHORT).show();
            finish();
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid weight. Please enter a valid number.", Toast.LENGTH_SHORT).show();
        }
    }
}
