package com.zybooks.weighttrackingapp;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;
import android.widget.Button;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import java.util.List;

public class DashboardActivity extends AppCompatActivity {

    private TextView goalWeightTextView;
    private Button addWeightButton, setGoalButton;
    private WeightRowAdapter adapter;

    private RecyclerView recyclerView;
    private DatabaseHelper dbHelper;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_dashboard);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Set up the Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Retrieve the user ID passed from LoginActivity
        userId = getIntent().getIntExtra("user_id", -1);

        // initialize UI components
        goalWeightTextView = findViewById(R.id.goal_weight_value);
        addWeightButton = findViewById(R.id.add_data_button);
        setGoalButton = findViewById(R.id.add_goal_button);
        recyclerView = findViewById(R.id.data_recycler_view);

        dbHelper = new DatabaseHelper(this);

        // displays goal not set if goal weight is 0.0 (default) and goal weight when set
        double goalWeight = dbHelper.getGoalWeightForUser(userId);
        if (goalWeight == 0.0) {
            goalWeightTextView.setText("Goal no set");
        } else {
            goalWeightTextView.setText(goalWeight + " lbs");
        }

        setupRecyclerView();

        // Open Add weight activity when the "Add" button is clicked
        addWeightButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                openAddWeightActivity();
            }
        });

        // Open Set Goal Activity when "Set Goal" button is clicked
        setGoalButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSetGoalActivity();
            }
        });

    }

    // Sets up RecyclerView with weight records from database
    private void setupRecyclerView() {
        // get weight records from database
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new WeightRowAdapter(this, dbHelper.getWeightsForUser(userId), dbHelper);
        recyclerView.setAdapter(adapter);
    }

    // Opens the activity for adding a new weight record
    private void openAddWeightActivity() {
        Intent intent = new Intent(DashboardActivity.this, AddWeightActivity.class);
        intent.putExtra("user_id", userId);
        startActivity(intent);
    }

    // Opens the activity for setting new goal weight
    private void openSetGoalActivity() {
        Intent intent = new Intent(DashboardActivity.this, SetGoalActivity.class);
        intent.putExtra("user_id", userId);
        startActivity(intent);
    }

    // Inflate the toolbar menu
    @Override
    // Load menu layout
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.toolbar_menu, menu);
        return true;
    }

    @Override
    // Refreshes the goal weight and weight list when the activity resumes
    protected void onResume() {
        super.onResume();
        displayGoalWeight();
        refreshWeightList();
    }


    // Updates the RecyclerView with the latest weight data
    private void refreshWeightList() {
        // Retrieve the updated weight entry list
        List<WeightRecord> updatedWeights = dbHelper.getWeightsForUser(userId);
        adapter.updateData(updatedWeights);
    }


    // Displays users goal weight on dashboard
    private void displayGoalWeight() {
        double goalWeight = dbHelper.getGoalWeightForUser(userId);

        // Show goal weight or "No goal set" if empty
        if (goalWeight > 0) {
            goalWeightTextView.setText(goalWeight + " lbs");
        } else {
            goalWeightTextView.setText("No goal set");
        }
    }


    @Override
    // Handles toolbar menu item clicks
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        // Handles SMS notifications menu click
        if (id == R.id.sms_notifications) {
            Intent intent = new Intent(DashboardActivity.this, SmsPermissionActivity.class);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);

    }
}