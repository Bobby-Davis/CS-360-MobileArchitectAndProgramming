package com.zybooks.weighttrackingapp;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Calendar;


 //AddWeightActivity allows the user to input a date and weight,
 //and then save the new weight entry into the database.

public class AddWeightActivity extends AppCompatActivity {

    // Declare UI components
    private EditText dateEditText, weightEditText;
    private Button addEntryButton, cancelButton;

    private DatabaseHelper dbHelper;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);

        // Initialize UI components
        dateEditText = findViewById(R.id.add_date);
        weightEditText = findViewById(R.id.add_weight);
        addEntryButton = findViewById(R.id.update_button);
        cancelButton = findViewById(R.id.cancel_button);

        // Initialize database helper and get userId passed from DashboardActivity
        dbHelper = new DatabaseHelper(this);
        userId = getIntent().getIntExtra("user_id", -1);

        // Set up the date picker for the date EditText
        dateEditText.setOnClickListener(v -> showDatePicker());

        // Set up Add Entry button
        addEntryButton.setOnClickListener(v -> {
            String date = dateEditText.getText().toString().trim();
            String weightStr = weightEditText.getText().toString().trim();

            if (date.isEmpty() || weightStr.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            } else {
                double weight = Double.parseDouble(weightStr);
                if (dbHelper.addWeightRecord(userId, date, weight)) {
                    Toast.makeText(this, "Weight entry added successfully!", Toast.LENGTH_SHORT).show();
                    finish(); // Go back to DashboardActivity
                } else {
                    Toast.makeText(this, "Failed to add entry. Try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Set up Cancel button
        cancelButton.setOnClickListener(v -> finish());
    }


     //Displays a DatePickerDialog to select a date.
    private void showDatePicker() {
        // Get the current date
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        // Show DatePickerDialog
        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    String formattedDate = String.format("%04d/%02d/%02d", selectedYear, selectedMonth + 1, selectedDay);
                    dateEditText.setText(formattedDate);
                }, year, month, day);
        datePickerDialog.show();
    }
}
