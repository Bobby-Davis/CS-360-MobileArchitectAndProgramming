package com.zybooks.weighttrackingapp;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameInput;
    private EditText passwordInput;
    private Button loginButton;
    private Button createAccountButton;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.login);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize views
        usernameInput = findViewById(R.id.username_input);
        passwordInput = findViewById(R.id.password_input);
        loginButton = findViewById(R.id.login_button);
        createAccountButton = findViewById(R.id.create_account_button);
        dbHelper = new DatabaseHelper(this);

        // Set up Login Button
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameInput.getText().toString().trim();
                String password = passwordInput.getText().toString().trim();

                // Validate inputs
                if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
                    Toast.makeText(LoginActivity.this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
                } else {
                    int userId = validateLogin(username, password); // Updated to return userId
                    if (userId != -1) { // Successful login
                        Toast.makeText(LoginActivity.this, "Login successful!", Toast.LENGTH_SHORT).show();

                        // Navigate to Dashboard and pass userId
                        Intent intent = new Intent(LoginActivity.this, DashboardActivity.class);
                        intent.putExtra("user_id", userId); // Pass user ID
                        startActivity(intent);
                        finish(); // Prevent going back to Login
                    } else {
                        Toast.makeText(LoginActivity.this, "Invalid credentials!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        // Set up Create Account Button
        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to Create Account page
                Intent intent = new Intent(LoginActivity.this, CreateAccountActivity.class);
                startActivity(intent);
            }
        });
    }

    /**
     *  Validates login credentials and returns user ID if valid.
     * @param username      Username input
     * @param password      Password input
     * @return              Returns user ID if credentials are valid, -1 if not
     */
    private int validateLogin(String username, String password) {
        // Get readable database
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // Query the database for user credentials
        Cursor cursor = db.query(
                "users",
                new String[]{"id"}, // Retrieve user ID
                "username=? AND password=?", // Query condition
                new String[]{username, password}, // Query parameters
                null,
                null,
                null
        );

        // Default user ID if not found
        int userId = -1;

        // If a record exists, retrieve the user ID
        if (cursor.moveToFirst()) {
            // Get user ID from the first column
            userId = cursor.getInt(0);
        }

        // Close cursor and database
        cursor.close();
        db.close();

        // Return user ID or -1 if not found
        return userId;
    }
}
