package com.zybooks.weighttrackingapp;

import android.app.AlertDialog;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.RecyclerView;
import androidx.annotation.NonNull;

import java.util.Collections;
import java.util.Comparator;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.List;


// WeightRowAdapter displays weight records in the RecyclerView
// It binds data from a list of WeighRecord to views defined in row_item.xml
// It also manages deleting records from the database.

public class WeightRowAdapter extends RecyclerView.Adapter<WeightRowAdapter.WeightRowViewHolder> {

    // List of weight records to display in the RecyclerView
    private final List<WeightRecord> weightRecords;
    // Activity context for managing resources and UI updates
    private final Context context;
    // Helper class to manage SQLite database operations
    private final DatabaseHelper dbHelper;


    /**
     *
     * @param context           Activity context
     * @param weightRecords     list of weight records to display
     * @param dbHelper          Database helper for performing database operations
     *
     */
    public WeightRowAdapter(Context context, List<WeightRecord> weightRecords, DatabaseHelper dbHelper) {
        this.context = context;
        this.weightRecords = weightRecords;
        this.dbHelper = dbHelper;
    }

    @NonNull
    @Override
    // Inflates the layout for each row item in the RecyclerView
    public WeightRowViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // Inflate the row_item.xml layout for each row
        View view = LayoutInflater.from(context).inflate(R.layout.row_item, parent, false);
        return new WeightRowViewHolder(view);
    }

    @Override
    // Binds data to the views for each row based on current position
    public void onBindViewHolder(WeightRowViewHolder holder, int position) {
        // Get the weight record for the current row
        WeightRecord record = weightRecords.get(position);

        // Sets date and weight values
        holder.dateTextView.setText(record.getDate());
        holder.weightTextView.setText(record.getWeight() + " lbs");

        // Set up the Delete button's click listener
        holder.deleteButton.setOnClickListener(v -> {
            // Show confirmation dialog
            new AlertDialog.Builder(context)
                    .setTitle("Delete Entry")
                    .setMessage("Are you sure you want to delete this entry?")
                    .setPositiveButton("Yes", (dialog, which) ->  {
                        // User clicked "Yes", delete record
                        dbHelper.deleteWeight(record.getId());
                        weightRecords.remove(position);
                        notifyItemRemoved(position);
                        Toast.makeText(context, "Weight entry deleted", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("No", (dialog, which) -> dialog.dismiss())
                    .show();
        });

        holder.updateButton.setOnClickListener(v -> {
            // show confirmation dialog
            new AlertDialog.Builder(context)
                    .setTitle("Update Entry")
                    .setMessage("Are you sure you want to update this entry?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        // Continue to update entry
                        Intent intent = new Intent(context, UpdateWeightActivity.class);
                        intent.putExtra("record_id", record.getId());
                        intent.putExtra("date", record.getDate());
                        intent.putExtra("weight", record.getWeight());
                        context.startActivity(intent);
                    })
                    .setNegativeButton("No", (dialog, which) -> dialog.dismiss())
                    .show();
        });
    }



    @Override
    // Returns the total number of items on the list
    public int getItemCount() {
        return weightRecords.size();
    }

    public void updateData(List<WeightRecord> newWeightList) {
        // clears old list
        this.weightRecords.clear();
        // adds new list data
        this.weightRecords.addAll(newWeightList);
        sortByDate();
        // notify RecyclerView to refresh
        notifyDataSetChanged();
    }

    // Sorts list by date in ascending order
    public void sortByDate() {
        // Date format that matches the stored date format (mm/dd/yyy)
        SimpleDateFormat dateFormat = new SimpleDateFormat("mm/dd/yyy");
        // Use Collections.sort to sort the list
        Collections.sort(weightRecords, new Comparator<WeightRecord>() {
            @Override
            public int compare(WeightRecord o1, WeightRecord o2) {
                try {
                    // parse the dates from the records
                    return dateFormat.parse(o1.getDate()).compareTo(dateFormat.parse(o2.getDate()));
                } catch (ParseException e) {
                    // if there is an error parsing the date, print error
                    e.printStackTrace();
                    // keep original order if parsing fails
                    return 0;
                }
            }
        });
    }

    // Manages individual rows in the RecyclerView
    static class WeightRowViewHolder extends RecyclerView.ViewHolder {

        // Displays the date of weight entry
        TextView dateTextView;
        // Displays the weight entry
        TextView weightTextView;
        // button to delete
        Button deleteButton, updateButton;

        public WeightRowViewHolder(View itemView) {
            super(itemView);

            // Link the views to their IDs in the row_item.xml layout
            dateTextView = itemView.findViewById(R.id.item_date);
            weightTextView = itemView.findViewById(R.id.item_weight);
            deleteButton = itemView.findViewById(R.id.delete_button);
            updateButton = itemView.findViewById(R.id.update_button);

        }
    }
}
