package com.zybooks.weighttrackingapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SmsPermissionActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "app_preferences";
    private static final String SMS_NOTIFICATIONS_KEY = "sms_notifications_enabled";

    private Switch smsToggleSwitch;

    private Button backToDashBoardButton;
    private boolean smsNotificationsEnabled;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        // Initialize SharedPreferences
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        smsNotificationsEnabled = prefs.getBoolean(SMS_NOTIFICATIONS_KEY, false);

        // Initialize Switch
        smsToggleSwitch = findViewById(R.id.sms_toggle);
        smsToggleSwitch.setChecked(smsNotificationsEnabled);
        backToDashBoardButton = findViewById(R.id.back_to_dashboard_button);

        // Set listener for toggle
        smsToggleSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                smsNotificationsEnabled = isChecked;

                // Save the updated state to SharedPreferences
                SharedPreferences.Editor editor = prefs.edit();
                editor.putBoolean(SMS_NOTIFICATIONS_KEY, smsNotificationsEnabled);
                editor.apply();


                // Show feedback to the user
                if (isChecked) {
                    Toast.makeText(SmsPermissionActivity.this, "SMS Notifications Enabled", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(SmsPermissionActivity.this, "SMS Notifications Disabled", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Back to dashboard
        backToDashBoardButton.setOnClickListener(v -> finish());


    }

}
