package com.zybooks.weighttrackingapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;

/**
 * DatabaseHelper manages the SQLite database for the Weight Tracking App.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    // name and version of database file
    private static final String DATABASE_NAME = "WeightTracking.db";
    private static final int DATABASE_VERSION = 1;

    // SQL statement to create the 'users' table
    private static final String CREATE_USERS_TABLE =
            "CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, password TEXT)";

    // SQL statement to create the 'weights' table
    private static final String CREATE_WEIGHTS_TABLE =
            "CREATE TABLE weights (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, date TEXT, weight REAL, FOREIGN KEY(user_id) REFERENCES users(id))";

    // SQL statement to create 'goals' table
    private static final String CREATE_GOALS_TABLE =
            "CREATE TABLE goals (user_id INTEGER PRIMARY KEY, goal_weight REAL, " +
                    "FOREIGN KEY(user_id) REFERENCES users(id))";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    // Execute SQL to create the 'users' and 'weights' table
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USERS_TABLE);
        db.execSQL(CREATE_WEIGHTS_TABLE);
        db.execSQL(CREATE_GOALS_TABLE);
    }

    @Override
    // Drop the 'users' or 'weights' table if it exists
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drops existing table sto recreates them to apply updates
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS weights");
        db.execSQL("DROP TABLE IF EXISTS goals");

        // Recreates the tables
        onCreate(db);
    }

    /**
     *  Gets the user ID for the username
     * @param username  Username to search for
     * @return          returns the user id if found, or -1 if not
     */
    public int getUserId(String username) {
        // opens database
        SQLiteDatabase db = this.getReadableDatabase();
        // query for getting user ID from username
        Cursor cursor = db.rawQuery("SELECT id FROM users WHERE username=?",
                 new String[]{username});

        // default value if no user is found
        int userId = -1;

        // check if record exists and gets user ID from first column
        if (cursor.moveToFirst()) {
            userId = cursor.getInt(0);
        }

        // Closes the cursor and database
        cursor.close();
        db.close();

        // return user ID
        return userId;
    }


    /**
     *  Gets all weight records for user ID
     *
     * @param userId        ID of the user
     * @return              returns list of weight entries
     */
    public List<WeightRecord> getWeightsForUser(int userId) {
        // List to store weight entries
        List<WeightRecord> weightList = new ArrayList<>();

        // opens database
        SQLiteDatabase db = this.getReadableDatabase();

        // query to get entry records for the user
        Cursor cursor = db.rawQuery("SELECT id, date, weight FROM weights WHERE user_id=?",
                new String[]{String.valueOf(userId)});

        // checks if there are any records
        if (cursor.moveToFirst()) {
            do {
                // gets the ID, date, and weight column
                int id = cursor.getInt(0);
                String date = cursor.getString(1);
                double weight = cursor.getDouble(2);

                // creates a new WeightRecords object and adds it to the list
                weightList.add(new WeightRecord(id, date, weight));
            } while (cursor.moveToNext());
        }

        // closes cursor and database
        cursor.close();
        db.close();

        // returns the list of weight entries.
        return weightList;
    }


    /**
     *  Gets the goal weight for user
     * @param userId        Id of the user whose goal weight is being retrieved
     * @return              returns goal weight if set, or 0.0 if not found.
     */
    public double getGoalWeightForUser(int userId) {
        // Opens database
        SQLiteDatabase db = this.getReadableDatabase();
        // default value for goal weight if not found
        double goalWeight = 0.0;

        // Query to get goal weight for user
        Cursor cursor = db.rawQuery("SELECT goal_weight FROM goals WHERE user_id=?",
                new String[]{String.valueOf(userId)});

        // check if record exists
        if (cursor.moveToFirst()) {
            // gets goal weight
            goalWeight = cursor.getDouble(0);
        }

        // closes cursor and database
        cursor.close();
        db.close();

        // returns users goal weight
        return goalWeight;
    }


    /**
     *  Sets goal weight for user
     * @param userId        ID for the user
     * @param goalWeight    new goal weight to set
     */
    public void setGoalWeightForUser( int userId, double goalWeight) {
        // Opens database
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("goal_weight", goalWeight);

        // inserts or replaces the records in the 'goals' table
        db.insertWithOnConflict("goals", null, values, SQLiteDatabase.CONFLICT_REPLACE);
        // closes database
        db.close();
    }

    /**
     *  Adds a new weight entry for the user
     * @param userId        ID of the user
     * @param date          date of weight entry
     * @param weight        weight that is recorded for entry
     * @return              returns true if weight entry is added and false if not
     */
    public boolean addWeightRecord(int userId, String date, double weight) {
        // opens database
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("date", date);
        values.put("weight", weight);

        // inserts the record
        long result = db.insert("weights", null, values);
        //close database
        db.close();
        // returns true if successful
        return result != -1;
    }

    /**
     * Updates a weight record in the database.
     *
     * @param id        The ID of the record to update.
     * @param newDate   The new date for the weight entry.
     * @param newWeight The new weight value.
     * @return          returns number of rows updated.
     */
    public int updateWeightEntry(int id, String newDate, double newWeight) {
        SQLiteDatabase db = this.getWritableDatabase(); // Open the database for writing

        // Use ContentValues to store the updated fields
        ContentValues values = new ContentValues();

        // updated date and weight
        values.put("date", newDate);
        values.put("weight", newWeight);

        // Update the 'weights' table
        int rowsUpdated = db.update("weights", values, "id=?", new String[]{String.valueOf(id)});

        // close database
        db.close();
        // returns the number of rows updated
        return rowsUpdated;
    }


    /**
     *  Deletes a weight entry based on ID
     * @param weightId      ID of the weight entry to delete
     */

    public void deleteWeight(int weightId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("weights", "id=?", new String[]{String.valueOf(weightId)});
        db.close();
    }
}