package com.zybooks.weighttrackingapp;

import android.content.ContentValues;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Toast;
import android.widget.Button;
import android.widget.EditText;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class CreateAccountActivity extends AppCompatActivity {

    private EditText usernameInput;
    private EditText passwordInput;
    private Button createAccountButton, cancelButton;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_create_account);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize UI components by linking them to layout elements
        usernameInput = findViewById(R.id.username_input);
        passwordInput = findViewById(R.id.password_input);
        createAccountButton = findViewById(R.id.create_account_button);
        cancelButton = findViewById(R.id.create_account_cancel_button);
        dbHelper = new DatabaseHelper(this);

        // Set up create account button function
        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // get and trim username and password input
                String username = usernameInput.getText().toString().trim();
                String password = passwordInput.getText().toString().trim();

                // validate inputs
                if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
                    // shows error message if either fields are empty
                    Toast.makeText(CreateAccountActivity.this,
                            "Please enter both username and password", Toast.LENGTH_SHORT).show();
                } else if (addUserToDatabase(username, password)) {
                    Toast.makeText(CreateAccountActivity.this,
                            "Account created successfully!", Toast.LENGTH_SHORT).show();
                    // close the activity after account is successfully created
                    finish();
                } else {
                    // shows error message if account creation fails
                    Toast.makeText(CreateAccountActivity.this,
                            "Account creation failed. Try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    /**
     *  Adds new user to database
     * @param username      the new username
     * @param password      the new password
     * @return              returns true if user is added successfully and false if not
     */

    private boolean addUserToDatabase(String username, String password) {
        // opens database to write
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        // Creates ContentValues to store data
        ContentValues values = new ContentValues();

        // Adds username and password to database
        values.put("username", username);
        values.put("password", password);


        try {
            // Insert into database (fails if username already exists)
            long result = db.insertOrThrow("users", null, values);
            db.close();
            // successful if result is not -1
            return result != -1;
        } catch (SQLiteConstraintException e) {
            // handle duplicate usernames
            Toast.makeText(this, "Username already exists. Please choose another.",
                    Toast.LENGTH_SHORT).show();
            db.close();
            return false;
        }
    }
}