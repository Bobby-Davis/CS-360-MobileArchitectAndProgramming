package com.zybooks.weighttrackingapp;


// WeightRecord represents a single weight entry
// It contains Id, date, and weight value
public class WeightRecord {

    private int id;
    private String date;
    private double weight;


    /**
     *
     *
     * @param id        ID for the weight record
     * @param date      Date of the weight record
     * @param weight    Weight value in lbs
     *
     *
     */
    public WeightRecord(int id, String date, double weight) {
        this.id = id;
        this.date = date;
        this.weight = weight;
    }

    // Getter for ID
    public int getId() {
        return id;
    }

    // Setter for ID
    public void setId(int id) {
        this.id = id;
    }

    // Getter for Date
    public String getDate() {
        return date;
    }

    // Setter for Date
    public void setDate(String date) {
        this.date = date;
    }

    //Getter for Weight
    public double getWeight() {
        return weight;
    }

    // Setter for Weight
    public void setWeight(double weight) {
        this.weight = weight;
    }

    @Override
    public String toString() {
        return "WeightRecord{" +
                "id=" + id +
                ", date='" + date + '\'' +
                ", weight = " + weight +
                '}';
    }

}
