package com.zybooks.weighttrackingapp;

import android.content.ContentValues;
import android.os.Bundle;
import android.app.DatePickerDialog;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.TextView;
import android.widget.DatePicker;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Calendar;

public class UpdateWeightActivity extends AppCompatActivity {

    private EditText dateInput, weightInput;
    private Button updateButton, cancelButton;

    private DatabaseHelper dbHelper;
    private int recordId; // ID of the record being updated

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        setContentView(R.layout.activity_update_weight);  // set layout

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        setContentView(R.layout.activity_update_weight); // Ensure you have the correct layout

        // Initialize views
        dateInput = findViewById(R.id.edit_date);
        weightInput = findViewById(R.id.edit_weight);
        updateButton = findViewById(R.id.update_button);
        cancelButton = findViewById(R.id.cancel_button);

        dbHelper = new DatabaseHelper(this);

        // Get data passed from previous activity
        recordId = getIntent().getIntExtra("record_id", -1);
        String date = getIntent().getStringExtra("date");
        double weight = getIntent().getDoubleExtra("weight", 0.0);

        // Populate fields with existing data
        dateInput.setText(date);
        weightInput.setText(String.valueOf(weight));

        // open calender when dateInput is clicked
        dateInput.setOnClickListener(v -> showDatePicker());

        // Set up Update button
        updateButton.setOnClickListener(v -> updateWeightRecord());

        // Set up Cancel button
        cancelButton.setOnClickListener(v -> finish());
    }

    // Shows a DatePickerDialog for selecting a date
    private void showDatePicker() {
        // Get current date
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(calendar.YEAR);
        int month = calendar.get(calendar.MONTH);
        int day = calendar.get(calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                // Format the date
                String formattedDate = String.format("%02d/%02d/%04d", (month + 1), dayOfMonth, year);
                // set the selected date in the input field
                dateInput.setText(formattedDate);
            }
        }, year, month, day);

        // Show the DatePicker dialog
        datePickerDialog.show();
    }


    // Updates the weight record in the database.

    private void updateWeightRecord() {
        String updatedDate = dateInput.getText().toString().trim();
        String updatedWeightStr = weightInput.getText().toString().trim();


        // Validate inputs
        if (updatedDate.isEmpty() || updatedWeightStr.isEmpty()) {
            Toast.makeText(this, "Please enter both date and weight.", Toast.LENGTH_SHORT).show();
            return;
        }

        double updatedWeight;

        try {
            updatedWeight = Double.parseDouble(updatedWeightStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid weight value.", Toast.LENGTH_SHORT).show();
            return;
        }


        // Update the record in the database
        ContentValues values = new ContentValues();
        values.put("date", updatedDate);
        values.put("weight", updatedWeight);

        int rowsUpdated = dbHelper.updateWeightEntry(recordId, updatedDate, updatedWeight);

        if (rowsUpdated > 0) {
            Toast.makeText(this, "Weight record updated successfully!", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Failed to update record.", Toast.LENGTH_SHORT).show();
        }
    }
}
